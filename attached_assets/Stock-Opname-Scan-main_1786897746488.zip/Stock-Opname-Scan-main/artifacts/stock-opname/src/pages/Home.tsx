import React, { useState, useMemo, useCallback } from 'react';
import { useProducts } from '@/hooks/useProducts';
import { useStoreName } from '@/hooks/useStoreName';
import { submitStockEntry } from '@/lib/sheets';
import { BarcodeScanner } from '@/components/BarcodeScanner';
import { ProductManager } from '@/components/ProductManager';
import { useToast } from '@/hooks/use-toast';
import { PackageSearch, Send, QrCode, RefreshCw, Box } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';

const TRANSACTIONS = [
  'Stock Opname',
  'Stock Awal',
  'Penjualan',
  'Pembelian',
  'Retur',
  'Lainnya'
];

export default function Home() {
  const { products, addProduct, removeProduct, updateProduct, replaceProducts } = useProducts();
  const [storeName, setStoreName] = useStoreName();
  const { toast } = useToast();

  const [transaction, setTransaction] = useState(TRANSACTIONS[0]);
  const [selectedBarcode, setSelectedBarcode] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  const submitMutation = useMutation({
    mutationFn: submitStockEntry,
    onSuccess: () => {
      toast({
        title: 'Berhasil',
        description: 'Data stock berhasil disimpan ke Google Sheets.',
      });
      setQuantity('');
    },
    onError: (err: any) => {
      toast({
        title: 'Gagal Menyimpan',
        description: err.message || 'Terjadi kesalahan saat menyimpan data.',
        variant: 'destructive',
      });
    }
  });

  const getPayload = () => {
    const product = products.find(p => p.barcode === selectedBarcode);
    return {
      store: storeName,
      transaction,
      product: product ? product.name : '',
      quantity: Number(quantity),
      barcode: selectedBarcode
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName || !transaction || !selectedBarcode || quantity === '') {
      toast({
        title: 'Peringatan',
        description: 'Mohon lengkapi semua form.',
        variant: 'destructive'
      });
      return;
    }
    submitMutation.mutate(getPayload());
  };

  const handleScanSuccess = useCallback((code: string) => {
    setIsScannerOpen(false);
    const product = products.find(p => p.barcode === code);
    if (product) {
      setSelectedBarcode(product.barcode);
      toast({
        title: 'Barcode Ditemukan',
        description: `Produk: ${product.name}`,
      });
    } else {
      toast({
        title: 'Barcode Tidak Dikenali',
        description: `${code}. Silakan pilih manual atau tambahkan produk baru.`,
        variant: 'destructive'
      });
      setSelectedBarcode('');
    }
  }, [products, toast]);

  const categories = useMemo(() => {
    const cats = new Set(products.map(p => p.category));
    return Array.from(cats).sort();
  }, [products]);

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col items-center pb-12">
      {/* Header */}
      <header className="w-full max-w-md bg-primary text-primary-foreground pt-10 pb-6 px-6 shadow-md rounded-b-3xl mb-6 sticky top-0 z-10">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h1 className="text-2xl font-serif font-bold tracking-tight">Erlangga</h1>
            <h2 className="text-sm text-primary-foreground/80 font-medium">Stock Opname</h2>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-white/10 rounded-full">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs font-medium">Ready</span>
          </div>
        </div>
      </header>

      <main className="w-full max-w-md px-4 flex-1 flex flex-col gap-6">
        <div className="bg-card border border-border shadow-sm rounded-2xl p-5 relative overflow-hidden">
          {/* Decorative accent blob */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-accent/10 rounded-full blur-2xl pointer-events-none" />
          
          <form onSubmit={handleSubmit} className="flex flex-col gap-5 relative z-10">
            {/* Store Name */}
            <div className="space-y-1.5">
              <label htmlFor="store" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Box size={16} className="text-muted-foreground" /> Nama Toko
              </label>
              <input
                id="store"
                type="text"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="w-full px-4 py-2.5 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all text-sm font-medium placeholder:text-muted-foreground/50"
                placeholder="Contoh: Toko Sentosa"
                required
              />
            </div>

            {/* Transaction Type */}
            <div className="space-y-1.5">
              <label htmlFor="transaction" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <RefreshCw size={16} className="text-muted-foreground" /> Tipe Transaksi
              </label>
              <div className="relative">
                <select
                  id="transaction"
                  value={transaction}
                  onChange={(e) => setTransaction(e.target.value)}
                  className="w-full px-4 py-2.5 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all text-sm appearance-none font-medium"
                  required
                >
                  {TRANSACTIONS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
                <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-muted-foreground">
                  <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              </div>
            </div>

            {/* Product Select with Scanner */}
            <div className="space-y-1.5">
              <label htmlFor="product" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <PackageSearch size={16} className="text-muted-foreground" /> Produk
              </label>
              
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <select
                    id="product"
                    value={selectedBarcode}
                    onChange={(e) => setSelectedBarcode(e.target.value)}
                    className="w-full h-[46px] px-4 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all text-sm appearance-none font-medium pr-8 truncate"
                    required
                  >
                    <option value="" disabled>Pilih Produk...</option>
                    {categories.map(cat => (
                      <optgroup key={cat} label={cat}>
                        {products.filter(p => p.category === cat).map(p => (
                          <option key={p.barcode} value={p.barcode}>{p.name}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                  <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-muted-foreground">
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                </div>
                
                <button
                  type="button"
                  onClick={() => setIsScannerOpen(true)}
                  className={`flex-none w-[46px] h-[46px] bg-accent text-accent-foreground rounded-xl shadow-sm hover:brightness-110 transition-all active:scale-95 flex items-center justify-center ${isScannerOpen ? 'animate-pulse' : ''}`}
                  aria-label="Scan Barcode"
                >
                  <QrCode size={22} />
                </button>
              </div>
              {selectedBarcode && (
                <p className="text-xs text-muted-foreground px-1 font-mono">Barcode: {selectedBarcode}</p>
              )}
            </div>

            {/* Quantity */}
            <div className="space-y-1.5">
              <label htmlFor="quantity" className="text-sm font-semibold text-foreground flex items-center gap-2">
                Jumlah Stok
              </label>
              <input
                id="quantity"
                type="number"
                min="0"
                step="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value ? parseInt(e.target.value, 10) : '')}
                className="w-full px-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all text-xl font-bold tracking-tight text-center"
                placeholder="0"
                required
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={submitMutation.isPending}
              className="w-full mt-2 py-3.5 bg-primary text-primary-foreground font-semibold rounded-xl shadow-md shadow-primary/20 hover:bg-primary/90 transition-all active:scale-[0.98] disabled:opacity-70 flex items-center justify-center gap-2 text-lg group"
            >
              {submitMutation.isPending ? (
                <>
                  <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <Send size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  Simpan Data
                </>
              )}
            </button>
          </form>
        </div>

        <ProductManager 
          products={products} 
          onAdd={addProduct} 
          onRemove={removeProduct} 
          onUpdate={updateProduct}
          onReplace={replaceProducts}
        />
      </main>

      <BarcodeScanner 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        onScanSuccess={handleScanSuccess} 
      />
    </div>
  );
}
